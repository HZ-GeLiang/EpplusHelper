EPPlus samples for .Net Core

Solution can be opened in Visual Studio for Windows or MacOS.
On other operation systems please use...

dotnet restore
dotnet run

... to execute sample. Non-windows operationsystems will requires libgdiplus to be installed. 
Please use your favorite package manager to install it. 
For example:

Homebrew on MacOS:
brew install mono-libgdiplus

apt-get:
apt-get install libgdiplus

Also see wiki on https://github.com/JanKallman/EPPlus/wiki for more details
