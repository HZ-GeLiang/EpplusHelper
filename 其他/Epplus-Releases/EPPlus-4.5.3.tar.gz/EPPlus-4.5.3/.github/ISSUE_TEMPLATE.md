Note: Please don't file an issue to ask a support related question. We are a small team and can't handle all questions. Questions are referred to https://stackoverflow.com/questions/tagged/epplus
If you have a bug, request of a new feature, make sure you follow these guidelines
[] Write a detailed description of your issue.
[] Attach a test to reproduce your issue, if it is a bug or unexpected behaviour. This is very important. 
[] If your issue requires a template xlsx file to be reproduced, make sure that you attach it to the issue.
